<!DOCTYPE html>
<html>

<head>
    <title>Tarifs Cinema Jacques Brel</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="description" content="Place your description here" />
    <meta name="keywords" content="put, your, keyword, here" />
    <meta name="author" content="Templates.com - website templates provider" />
    <link href="style.css" rel="stylesheet" type="text/css" />
    <script src="js/jquery-1.4.2.min.js" type="text/javascript"></script>
    <script src="js/cufon-yui.js" type="text/javascript"></script>
    <script src="js/cufon-replace.js" type="text/javascript"></script>
    <script src="js/Gill_Sans_400.font.js" type="text/javascript"></script>
    <script src="js/script.js" type="text/javascript"></script>

</head>

<body id="page12">
    <div id="content">
        <div class="line-hor"></div>
        <div class="box">
            <div class="border-right">
                <div class="border-left">
                    <div class="inner">
                        <h3><span>Tarifs</span></h3>
                        <div class="img-box1 alt"><img src="images/4page-img.jpg" alt="" /></div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>