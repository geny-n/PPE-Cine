<center><h3>Connexion</h3></center><hr><br>
<form method = "post" action="" id="connexion_form">
	<table border = "0">
	<tr>
		<table border = "0">
		<tr>
			<td>
			<h4>Email : </h4>
			<input type="text"  name="email" value ="">
		    </td>
		</tr>

		<tr>
			<td>
			<br>
			<h4>Mot de passe : * </h4>
			<input type="password"  name="mdp" value ="">
		    </td>
		</tr>
		
		</table>
	</tr>
	<tr>
		<br>
		<div class="wrapper"> 
			<a href="#" class="link2"  onclick="document.getElementById('connexion_form').submit();">
                <span><span>Connexion</span></span>
            </a>          
                
        </div>
        <br>

		</table>
	</tr>
	<tr>
		<p> * Champs Obligatoires </p>
	</tr>
	</table>
	
</form>

<hr>
<br>
<td><h4>Si vous n'avez toujours pas de compte</h4></td><br>
<div class="wrapper">
	<a href="index.php?page=14 " class="link2">
        <span>
            <span>Inscription</span>
        </span>
    </a>
</div>
<br>

